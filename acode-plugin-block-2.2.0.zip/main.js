const pluginId = "com.blocklang.acode";

const svgIconUrl = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%232a2a2a'/%3E%3Cg fill='none' stroke='%23ffffff' stroke-width='5' stroke-linejoin='round'%3E%3Crect x='25' y='20' width='15' height='60'/%3E%3Cpolygon points='45,20 70,20 75,32.5 70,45 45,45'/%3E%3Cpolygon points='45,55 75,55 80,67.5 75,80 45,80'/%3E%3C/g%3E%3C/svg%3E";

class BlockPlugin {
    constructor() {
        this._onFileUpdate = this.onFileUpdate.bind(this);
        this._onEditorChange = this.onEditorChange.bind(this);
        this.statusCheckTimer = null;
        this.lastOutput = null;
        this.lastHtmlOutput = null;
        this.lastExecutionStats = null;
        this.activeTheme = window.localStorage.getItem('block_ui_theme') || 'cyber';
        try {
            this.serverProfiles = JSON.parse(window.localStorage.getItem('block_server_profiles') || '[]');
        } catch (e) {
            this.serverProfiles = [];
        }
        if (!Array.isArray(this.serverProfiles) || this.serverProfiles.length === 0) {
            this.serverProfiles = [
                { name: 'Localhost Engine', url: 'http://127.0.0.1:8080/api/run', token: '' }
            ];
            this.saveProfiles();
        }
    }

    saveProfiles() {
        window.localStorage.setItem('block_server_profiles', JSON.stringify(this.serverProfiles));
    }

    getActiveProfile() {
        const idx = parseInt(window.localStorage.getItem('block_active_profile_idx') || '0', 10);
        return this.serverProfiles[idx] || this.serverProfiles[0];
    }

    async init($page) {
        // Inject comprehensive themes and responsive mobile styles
        const style = document.createElement('style');
        style.id = 'block-plugin-style';
        style.innerHTML = `
            .icon-block-lang {
                background-image: url("${svgIconUrl}");
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center;
                width: 26px;
                height: 26px;
                display: inline-block;
                margin: 11px 8px 0 8px;
                cursor: pointer;
                border-radius: 4px;
                float: right;
            }
            .file_type_blk::before, .file_type_block::before, .file_type_blkl::before, .file_type_blkp::before {
                content: '' !important;
                display: inline-block !important;
                width: 1.1em;
                height: 1.1em;
                background-image: url("${svgIconUrl}");
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                vertical-align: middle;
            }

            /* Quick Mobile Action Bar */
            #block-quick-bar {
                display: flex;
                gap: 6px;
                overflow-x: auto;
                background: #121215;
                padding: 6px 10px;
                border-top: 1px solid #27272a;
                white-space: nowrap;
                z-index: 10;
            }
            .block-tag-btn {
                background: #27272a;
                color: #e4e4e7;
                border: 1px solid #3f3f46;
                padding: 4px 10px;
                border-radius: 6px;
                font-family: monospace;
                font-size: 12px;
                cursor: pointer;
                transition: all 0.2s;
            }
            .block-tag-btn:active {
                background: #3b82f6;
                color: #ffffff;
            }

            /* Floating Action Buttons (FAB) for Mobile */
            #block-fab-container {
                position: fixed;
                bottom: 80px;
                right: 20px;
                display: flex;
                flex-direction: column;
                gap: 10px;
                z-index: 999;
            }
            .block-fab {
                width: 44px;
                height: 44px;
                border-radius: 50%;
                background: #3b82f6;
                color: #fff;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.5);
                border: none;
                cursor: pointer;
            }
            .block-fab.run { background: #10b981; }

            /* Persistent Modal Panel with Themes */
            .block-panel-modal {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                height: 55vh;
                background: #09090b;
                color: #f4f4f5;
                border-top: 2px solid #3b82f6;
                z-index: 99999;
                display: flex;
                flex-direction: column;
                box-shadow: 0 -10px 30px rgba(0,0,0,0.85);
                font-family: monospace;
            }
            .block-panel-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: #18181b;
                padding: 8px 14px;
                border-bottom: 1px solid #27272a;
            }
            .block-panel-tabs {
                display: flex;
                gap: 10px;
            }
            .block-tab {
                padding: 4px 10px;
                font-size: 12px;
                color: #a1a1aa;
                cursor: pointer;
                border-radius: 4px;
            }
            .block-tab.active {
                color: #ffffff;
                background: #27272a;
                font-weight: bold;
            }
            .block-panel-body {
                flex: 1;
                padding: 12px;
                overflow-y: auto;
                font-size: 13px;
                line-height: 1.5;
                white-space: pre-wrap;
                word-break: break-all;
            }
            
            /* Performance Benchmark Bar */
            .block-perf-bar {
                display: flex;
                height: 4px;
                background: #27272a;
                border-radius: 2px;
                overflow: hidden;
                margin: 6px 14px;
            }
            .perf-net { background: #3b82f6; }
            .perf-exec { background: #10b981; }

            .block-panel-footer {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 6px 14px;
                background: #18181b;
                border-top: 1px solid #27272a;
                font-size: 11px;
                color: #a1a1aa;
            }
            .panel-act-btn {
                background: #27272a;
                color: #fff;
                border: 1px solid #3f3f46;
                padding: 2px 8px;
                border-radius: 4px;
                cursor: pointer;
                margin-left: 4px;
            }
        `;
        document.head.appendChild(style);

        // Action Buttons in Header
        this.$btn = document.createElement('span');
        this.$btn.className = 'icon action-btn';
        this.$btn.onclick = this.showMenu.bind(this);
        this.$btn.style.backgroundImage = `url("${svgIconUrl}")`;
        this.$btn.style.backgroundSize = '20px';
        this.$btn.style.backgroundRepeat = 'no-repeat';
        this.$btn.style.backgroundPosition = 'center';

        this.$runBtn = document.createElement('span');
        this.$runBtn.className = 'icon play_arrow action-btn';
        this.$runBtn.onclick = this.runBlockCode.bind(this);
        this.$runBtn.style.color = '#10b981';
        this.$runBtn.style.fontSize = '24px';

        // Initialize Ace Editor Snippets & Auto-Close Listener
        this.registerSnippets();
        this.initAutoCloseTags();

        // Listen for editor file events
        editorManager.on('switch-file', this._onFileUpdate);
        editorManager.on('rename-file', this._onFileUpdate);
        this._onFileUpdate();

        // Register Commands & Hotkeys
        editorManager.editor.commands.addCommand({
            name: 'Run Block Engine Code',
            bindKey: {win: 'Ctrl-R', mac: 'Command-R'},
            exec: this.runBlockCode.bind(this)
        });

        editorManager.editor.commands.addCommand({
            name: 'Format Block Code',
            bindKey: {win: 'Ctrl-Shift-F', mac: 'Command-Shift-F'},
            exec: this.formatCode.bind(this)
        });
    }

    initAutoCloseTags() {
        const editor = editorManager.editor;
        if (!editor) return;
        editor.on('change', this._onEditorChange);
    }

    onEditorChange(e) {
        if (e.action !== 'insert') return;
        const isBlock = file && file.name && (
            file.name.endsWith('.blk') || file.name.endsWith('.blkp') || file.name.endsWith('.blkl') ||
            file.name.endsWith('.block') || file.name.endsWith('.blocklite') || file.name.endsWith('.blockplus')
        );

        const cursor = editorManager.editor.getCursorPosition();
        const line = editorManager.editor.session.getLine(cursor.row);
        const textBefore = line.substring(0, cursor.column);
        
        // Auto close tag on typing '>' (e.g. typing <py> -> inserts </py>)
        const match = textBefore.match(/<([a-zA-Z0-9_\-]+)>$/);
        if (match && !textBefore.includes('</')) {
            const tag = match[1];
            const closeTag = `</${tag}>`;
            // Check if closing tag isn't already immediately after
            const textAfter = line.substring(cursor.column);
            if (!textAfter.startsWith(closeTag)) {
                editorManager.editor.insert(`\n\n${closeTag}`);
                editorManager.editor.navigateUp(1);
            }
        }
    }

    registerSnippets() {
        if (!window.ace) return;
        ace.config.loadModule("ace/snippets/html", function(m) {
            const snippetManager = ace.require("ace/snippets").snippetManager;
            if (!m) m = { snippets: [] };
            m.snippets = m.snippets || [];
            const mySnippets = [
                { name: "server", content: "<server port=\"${1:8080}\">\n  <static path=\"/public\" dir=\"./static\" />\n  <route path=\"${2:/}\">\n    $3\n  </route>\n</server>", tabTrigger: "server" },
                { name: "route", content: "<route path=\"${1:/api}\">\n  $2\n</route>", tabTrigger: "route" },
                { name: "static", content: "<static path=\"${1:/static}\" dir=\"${2:./public}\" />", tabTrigger: "static" },
                { name: "import", content: "<import src=\"${1:module.blk}\" />", tabTrigger: "import" },
                { name: "define", content: "<define lang=\"${1:lang_name}\" cmd=\"${2:executable}\" ext=\".${3:ext}\" />", tabTrigger: "define" },
                { name: "python", content: "<py>\n$1\n</py>", tabTrigger: "py" },
                { name: "javascript", content: "<js>\n$1\n</js>", tabTrigger: "js" },
                { name: "typescript", content: "<ts>\n$1\n</ts>", tabTrigger: "ts" },
                { name: "php", content: "<php>\n$1\n</php>", tabTrigger: "php" },
                { name: "powershell", content: "<ps>\n$1\n</ps>", tabTrigger: "ps" },
                { name: "lua", content: "<lua>\n$1\n</lua>", tabTrigger: "lua" },
                { name: "ruby", content: "<ruby>\n$1\n</ruby>", tabTrigger: "ruby" },
                { name: "sql", content: "<sql>\n$1\n</sql>", tabTrigger: "sql" },
                { name: "html", content: "<html>\n$1\n</html>", tabTrigger: "html" },
                { name: "json", content: "<json>\n{\n  \"${1:key}\": \"${2:value}\"\n}\n</json>", tabTrigger: "json" },
                { name: "rust", content: "<rust>\n$1\n</rust>", tabTrigger: "rust" },
                { name: "go", content: "<go>\n$1\n</go>", tabTrigger: "go" },
                { name: "cpp", content: "<cpp>\n$1\n</cpp>", tabTrigger: "cpp" },
                { name: "c", content: "<c>\n$1\n</c>", tabTrigger: "c" },
                { name: "csharp", content: "<cs>\n$1\n</cs>", tabTrigger: "cs" },
                { name: "java", content: "<java>\n$1\n</java>", tabTrigger: "java" },
                { name: "kotlin", content: "<kt>\n$1\n</kt>", tabTrigger: "kt" },
                { name: "dart", content: "<dart>\n$1\n</dart>", tabTrigger: "dart" },
                { name: "zig", content: "<zig>\n$1\n</zig>", tabTrigger: "zig" },
                { name: "perl", content: "<perl>\n$1\n</perl>", tabTrigger: "perl" },
                { name: "r", content: "<r>\n$1\n</r>", tabTrigger: "r" },
                { name: "bash", content: "<bash>\n$1\n</bash>", tabTrigger: "bash" },
                { name: "hb-if", content: "{{#if ${1:variable}}}\n  $2\n{{else}}\n  $3\n{{/if}}", tabTrigger: "hb-if" },
                { name: "hb-unless", content: "{{#unless ${1:variable}}}\n  $2\n{{/unless}}", tabTrigger: "hb-unless" },
                { name: "hb-each", content: "{{#each ${1:list}}}\n  <div>{{@index}}: {{this}}</div>\n{{/each}}", tabTrigger: "hb-each" }
            ];
            m.snippets.push.apply(m.snippets, mySnippets);
            snippetManager.register(m.snippets, "html");

            // Register Custom Ace Autocompleter for Block Language
            const langCompleter = {
                getCompletions: function(editor, session, pos, prefix, callback) {
                    const line = session.getLine(pos.row);
                    const before = line.substring(0, pos.column);
                    
                    const wordList = [
                        { caption: "<py>", value: "py>\n\t\n</py>", meta: "Python Block", score: 1000 },
                        { caption: "<js>", value: "js>\n\t\n</js>", meta: "JavaScript Block", score: 1000 },
                        { caption: "<ts>", value: "ts>\n\t\n</ts>", meta: "TypeScript Block", score: 950 },
                        { caption: "<php>", value: "php>\n\t\n</php>", meta: "PHP Block", score: 900 },
                        { caption: "<ruby>", value: "ruby>\n\t\n</ruby>", meta: "Ruby Block", score: 900 },
                        { caption: "<lua>", value: "lua>\n\t\n</lua>", meta: "Lua Block", score: 900 },
                        { caption: "<ps>", value: "ps>\n\t\n</ps>", meta: "PowerShell Block", score: 900 },
                        { caption: "<sql>", value: "sql>\n\t\n</sql>", meta: "SQL Block", score: 900 },
                        { caption: "<html>", value: "html>\n\t\n</html>", meta: "HTML Template", score: 900 },
                        { caption: "<json>", value: "json>\n\t{\n\t\t\n\t}\n</json>", meta: "JSON Output", score: 900 },
                        { caption: "<go>", value: "go>\n\t\n</go>", meta: "Go Block (Plus)", score: 850 },
                        { caption: "<rust>", value: "rust>\n\t\n</rust>", meta: "Rust Block (Plus)", score: 850 },
                        { caption: "<cpp>", value: "cpp>\n\t\n</cpp>", meta: "C++ Block (Plus)", score: 850 },
                        { caption: "<c>", value: "c>\n\t\n</c>", meta: "C Block (Plus)", score: 850 },
                        { caption: "<cs>", value: "cs>\n\t\n</cs>", meta: "C# Block (Plus)", score: 850 },
                        { caption: "<java>", value: "java>\n\t\n</java>", meta: "Java Block (Plus)", score: 850 },
                        { caption: "<kt>", value: "kt>\n\t\n</kt>", meta: "Kotlin Block (Plus)", score: 850 },
                        { caption: "<dart>", value: "dart>\n\t\n</dart>", meta: "Dart Block (Plus)", score: 850 },
                        { caption: "<zig>", value: "zig>\n\t\n</zig>", meta: "Zig Block (Plus)", score: 850 },
                        { caption: "<perl>", value: "perl>\n\t\n</perl>", meta: "Perl Block (Plus)", score: 850 },
                        { caption: "<r>", value: "r>\n\t\n</r>", meta: "R Block (Plus)", score: 850 },
                        { caption: "<bash>", value: "bash>\n\t\n</bash>", meta: "Bash Block (Plus)", score: 850 },
                        { caption: "<server>", value: "server port=\"8080\">\n\t\n</server>", meta: "HTTP Server", score: 950 },
                        { caption: "<route>", value: "route path=\"/\">\n\t\n</route>", meta: "Server Route", score: 950 },
                        { caption: "<static>", value: "static path=\"/static\" dir=\"./public\" />", meta: "Static Assets", score: 900 },
                        { caption: "<import>", value: "import src=\"module.blk\" />", meta: "Import Module", score: 900 },
                        { caption: "<define>", value: "define lang=\"\" cmd=\"\" ext=\".\" />", meta: "Custom Runtime", score: 900 },
                        { caption: "{{#if}}", value: "{{#if }}\n\t\n{{/if}}", meta: "Handlebars If", score: 800 },
                        { caption: "{{#each}}", value: "{{#each }}\n\t\n{{/each}}", meta: "Handlebars Loop", score: 800 }
                    ];

                    callback(null, wordList.map(item => ({
                        caption: item.caption,
                        value: before.endsWith('<') ? item.value : (item.caption.startsWith('<') ? '<' + item.value : item.value),
                        meta: item.meta,
                        score: item.score
                    })));
                }
            };
            if (editorManager.editor && editorManager.editor.completers) {
                editorManager.editor.completers.push(langCompleter);
            }
        });
        });
    }

    onFileUpdate() {
        const file = editorManager.activeFile;
        const exts = ['.blk', '.block', '.blkl', '.blocklite', '.blkp', '.blockplus'];
        const isBlock = file && file.name && exts.some(ext => file.name.endsWith(ext));
        
        if (isBlock) {
            editorManager.editor.getSession().setMode('ace/mode/html');
            const header = document.querySelector('#main-header') || document.querySelector('header');
            if (header && !this.$btn.parentElement) {
                header.appendChild(this.$btn);
                header.appendChild(this.$runBtn);
            }
            this.showQuickBar(true);
        } else {
            if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
            if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
            this.showQuickBar(false);
        }
    }

    showQuickBar(show) {
        let bar = document.getElementById('block-quick-bar');
        if (show) {
            if (!bar) {
                bar = document.createElement('div');
                bar.id = 'block-quick-bar';
                const tags = ['<py>', '<js>', '<html>', '<php>', '<sql>', '<rust>', '<go>', '<cpp>', '</py>', '</js>', '</html>'];
                tags.forEach(tag => {
                    const btn = document.createElement('button');
                    btn.className = 'block-tag-btn';
                    btn.innerText = tag;
                    btn.onclick = () => {
                        editorManager.editor.insert(tag + '\n');
                        editorManager.editor.focus();
                    };
                    bar.appendChild(btn);
                });
                
                const wizardBtn = document.createElement('button');
                wizardBtn.className = 'block-tag-btn';
                wizardBtn.style.background = '#8b5cf6';
                wizardBtn.style.color = '#fff';
                wizardBtn.innerText = '⚡ Template Wizard';
                wizardBtn.onclick = () => this.insertTemplate();
                bar.appendChild(wizardBtn);

                const editorContainer = document.querySelector('#editor') || document.body;
                editorContainer.parentElement.insertBefore(bar, editorContainer);
            }
            bar.style.display = 'flex';
        } else if (bar) {
            bar.style.display = 'none';
        }
    }

    insertTemplate() {
        const tpl = `<py>\n# Data Processing Block\nuser_name = "Acode Developer"\nscores = [95, 98, 100]\navg_score = sum(scores) / len(scores)\n</py>\n\n<js>\n// Interoperable JS Scope\nconsole.log("Welcome,", user_name);\nconsole.log("Average Score:", avg_score);\nstatus_badge = "Active";\n</js>\n\n<html>\n<div style="background:#18181b; color:#fff; padding:20px; border-radius:12px;">\n  <h2>🚀 {{user_name}}</h2>\n  <p>Status: {{status_badge}} | Average: {{avg_score}}</p>\n</div>\n</html>\n`;
        editorManager.editor.insert(tpl);
        editorManager.editor.focus();
    }

    async showMenu() {
        const activeProf = this.getActiveProfile();
        const opts = [
            `🚀 Run Code (Server: ${activeProf.name})`,
            '🌐 Preview Rendered HTML',
            '⚡ Quick Interactive REPL Playground',
            '🎨 Auto-Fix & Format Code',
            '🔍 Offline Syntax Diagnostics',
            '🖥️ Server Profile Manager',
            '📥 Export Execution Output Log',
            'ℹ️ About Block Engine Ultimate v2.1.0'
        ];
        const res = await window.acode.select(`⚡ Block Engine (${activeProf.name})`, opts);
        if (!res) return;
        if (res.includes('Run Code')) this.runBlockCode();
        else if (res.includes('Preview Rendered HTML')) this.previewHtml();
        else if (res.includes('Interactive REPL Playground')) this.openRepl();
        else if (res.includes('Auto-Fix & Format')) this.formatCode();
        else if (res.includes('Offline Syntax Diagnostics')) this.runDiagnostics();
        else if (res.includes('Server Profile Manager')) this.openProfileManager();
        else if (res.includes('Export Execution Output Log')) this.exportLog();
        else if (res.includes('About Block Engine')) this.showAbout();
    }

    async openProfileManager() {
        const profNames = this.serverProfiles.map((p, i) => `${i === parseInt(window.localStorage.getItem('block_active_profile_idx') || '0', 10) ? '✔ ' : ''}${p.name} (${p.url})`);
        profNames.push('➕ Add New Server Profile');
        
        const res = await window.acode.select('Server Profile Manager', profNames);
        if (!res) return;
        if (res.includes('Add New Server Profile')) {
            const name = await window.acode.prompt('Profile Name', 'Dev Server');
            if (!name) return;
            const url = await window.acode.prompt('API URL', 'http://192.168.1.100:8080/api/run');
            if (!url) return;
            const token = await window.acode.prompt('X-Api-Token (Optional)', '');
            this.serverProfiles.push({ name, url, token: token || '' });
            this.saveProfiles();
            if (window.toast) window.toast('Profile added!', 1500);
        } else {
            const idx = profNames.indexOf(res);
            if (idx >= 0 && idx < this.serverProfiles.length) {
                window.localStorage.setItem('block_active_profile_idx', idx.toString());
                if (window.toast) window.toast(`Switched profile to '${this.serverProfiles[idx].name}'`, 1500);
            }
        }
    }

    async openRepl() {
        const langs = ['Python (<py>)', 'JavaScript (<js>)', 'PHP (<php>)', 'Lua (<lua>)', 'SQL (<sql>)'];
        const sel = await window.acode.select('Select REPL Language', langs);
        if (!sel) return;

        let tag = 'py';
        if (sel.includes('JavaScript')) tag = 'js';
        if (sel.includes('PHP')) tag = 'php';
        if (sel.includes('Lua')) tag = 'lua';
        if (sel.includes('SQL')) tag = 'sql';

        const codeSnippet = await window.acode.prompt(`Enter one-liner code for <${tag}>`, tag === 'py' ? 'print("Hello from Mobile REPL!")' : 'console.log("Hello from REPL!")');
        if (!codeSnippet) return;

        const fullBlock = `<${tag}>\n${codeSnippet}\n</${tag}>`;
        this.executeCodeDirect(fullBlock);
    }

    runDiagnostics() {
        const code = editorManager.editor.getValue();
        const lines = code.split('\n');
        let errors = [];
        let openTags = [];

        lines.forEach((line, idx) => {
            const trimmed = line.trim();
            const match = trimmed.match(/^<(\/)?([a-zA-Z0-9_\-]+)>$/);
            if (match) {
                const isClosing = match[1] !== undefined;
                const tag = match[2].toLowerCase();
                if (!isClosing) {
                    openTags.push({ tag, line: idx + 1 });
                } else {
                    if (openTags.length === 0) {
                        errors.push(`Line ${idx + 1}: Closing tag </${tag}> has no matching opening tag.`);
                    } else {
                        const last = openTags.pop();
                        if (last.tag !== tag) {
                            errors.push(`Line ${idx + 1}: Unmatched closing tag </${tag}> (expected </${last.tag}> opened at Line ${last.line}).`);
                        }
                    }
                }
            }
        });

        openTags.forEach(item => {
            errors.push(`Line ${item.line}: Unclosed opening tag <${item.tag}>.`);
        });

        if (errors.length === 0) {
            window.acode.alert('Syntax Check Passed', '✅ All polyglot block tags are balanced and valid!');
        } else {
            const html = `<div style="color:#ef4444; font-family:monospace; text-align:left;">${errors.join('<br>')}</div>`;
            window.acode.alert('Syntax Warnings', html);
        }
    }

    formatCode() {
        let code = editorManager.editor.getValue();
        // Auto fix legacy tag names
        code = code.replace(/<python>/gi, '<py>').replace(/<\/python>/gi, '</py>')
                   .replace(/<javascript>/gi, '<js>').replace(/<\/javascript>/gi, '</js>')
                   .replace(/<powershell>/gi, '<ps>').replace(/<\/powershell>/gi, '</ps>');

        const lines = code.split('\n');
        let formatted = [];
        let indent = 0;

        lines.forEach(line => {
            let trimmed = line.trim();
            if (trimmed.startsWith('</')) {
                indent = Math.max(0, indent - 1);
            }
            formatted.push('  '.repeat(indent) + trimmed);
            if (trimmed.match(/^<[a-zA-Z0-9_\-]+>$/) && !trimmed.startsWith('</')) {
                indent++;
            }
        });

        editorManager.editor.setValue(formatted.join('\n'));
        if (window.toast) window.toast('Auto-fixed aliases & formatted!', 1500);
    }

    exportLog() {
        if (!this.lastOutput) {
            window.acode.alert('Export Log', 'No execution log available yet. Run a script first!');
            return;
        }
        window.acode.prompt('Log Output', this.lastOutput);
    }

    showAbout() {
        const html = `
            <div style="text-align: center;">
                <img src="${svgIconUrl}" style="width: 80px; height: 80px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">
                <h3 style="margin: 0; color: #fff; font-family: sans-serif;">Block Engine Ultimate</h3>
                <p style="margin: 6px 0 12px 0; color: #10b981; font-size: 14px; font-weight: bold;">v2.1.0 (Mobile Mega Suite)</p>
                <div style="color: #aaa; font-size: 12px; text-align: left; background: #18181b; padding: 12px; border-radius: 8px; border: 1px solid #27272a; line-height: 1.6;">
                    • <strong>Multi-Profile Manager</strong>: Switch between Dev / Cloud PCs<br>
                    • <strong>Interactive REPL Playground</strong>: Test code snippets on mobile<br>
                    • <strong>Auto-Close Tags & Keyboard Toolbar</strong>: Fast touch typing<br>
                    • <strong>Performance Visualizer</strong>: Latency & execution timing<br>
                    • <strong>HTML Live Renderer</strong>: Mobile web preview tab<br>
                    • <strong>Auto-Fixer & Diagnostics</strong>: Auto alias conversion
                </div>
            </div>
        `;
        window.acode.alert('About Extension', html);
    }

    async runBlockCode() {
        const code = editorManager.editor.getValue();
        this.executeCodeDirect(code);
    }

    async executeCodeDirect(code) {
        const prof = this.getActiveProfile();
        const startTime = Date.now();

        if (!prof.url || (!prof.url.startsWith('http://') && !prof.url.startsWith('https://'))) {
            this.showPanelOutput('❌ Security Error: Server Profile URL must start with http:// or https://', 'error', 0);
            return;
        }

        try {
            const headers = { 'Content-Type': 'text/plain' };
            if (prof.token) headers['X-Api-Token'] = prof.token;

            const response = await fetch(prof.url, {
                method: 'POST',
                headers: headers,
                body: code,
                signal: AbortSignal.timeout(10000)
            });
            
            const elapsed = Date.now() - startTime;

            if (!response.ok) {
                let errorMsg = 'Server status ' + response.status;
                try {
                    const errResult = await response.json();
                    if (errResult && errResult.error) errorMsg = errResult.error;
                } catch (_) {}
                this.showPanelOutput(`❌ Execution Error (${response.status}):\n${errorMsg}`, 'error', elapsed);
                return;
            }

            const result = await response.json();
            
            if (result.status === 'success') {
                const output = (result.output != null) ? result.output : '(Code executed successfully with zero stdout output)';
                this.lastOutput = output;
                this.showPanelOutput(output, 'success', elapsed);
            } else {
                const errorText = (result.error != null) ? result.error : 'Unknown execution failure';
                this.showPanelOutput(`❌ Execution Failed:\n${errorText}`, 'error', elapsed);
            }
        } catch (e) {
            this.showPanelOutput(`🔌 Connection Failed:\nCould not reach ${prof.url} (${prof.name}).\nIs the PC engine running ('block serve')?\n\nDetails: ${e.message}`, 'error', 0);
        }
    }

    showPanelOutput(content, status, elapsed) {
        let panel = document.getElementById('block-console-panel');
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'block-console-panel';
            panel.className = 'block-panel-modal';
            panel.innerHTML = `
                <div class="block-panel-header">
                    <div class="block-panel-tabs">
                        <span class="block-tab active" id="tab-output" onclick="window.acodeBlockPlugin.switchTab('output')">Console Output</span>
                        <span class="block-tab" id="tab-html" onclick="window.acodeBlockPlugin.switchTab('html')">HTML Render</span>
                    </div>
                    <div>
                        <button class="panel-act-btn" onclick="window.acodeBlockPlugin.exportLog()">Export Log</button>
                        <button style="background:none; border:none; color:#ef4444; font-size:18px; cursor:pointer; margin-left:10px;" onclick="window.acodeBlockPlugin.closePanel()">✕</button>
                    </div>
                </div>
                <div class="block-perf-bar">
                    <div class="perf-net" style="width:30%;"></div>
                    <div class="perf-exec" style="width:70%;"></div>
                </div>
                <div class="block-panel-body" id="block-panel-body"></div>
                <div class="block-panel-footer">
                    <span id="block-panel-status">Status: Success</span>
                    <span id="block-panel-time">Time: 0ms</span>
                </div>
            `;
            document.body.appendChild(panel);
        }

        window.acodeBlockPlugin = this;
        panel.style.display = 'flex';

        const body = document.getElementById('block-panel-body');
        const statusSpan = document.getElementById('block-panel-status');
        const timeSpan = document.getElementById('block-panel-time');

        body.innerText = content;
        body.style.color = status === 'error' ? '#ef4444' : '#f4f4f5';
        statusSpan.innerText = status === 'error' ? '🔴 Execution Error' : '🟢 Success';
        timeSpan.innerText = `Total: ${elapsed}ms`;
    }

    switchTab(tab) {
        const body = document.getElementById('block-panel-body');
        const tabOut = document.getElementById('tab-output');
        const tabHtml = document.getElementById('tab-html');

        if (tab === 'output') {
            tabOut.classList.add('active');
            tabHtml.classList.remove('active');
            body.innerText = this.lastOutput || '(No console output)';
        } else if (tab === 'html') {
            tabHtml.classList.add('active');
            tabOut.classList.remove('active');
            
            const code = editorManager.editor.getValue();
            const match = code.match(/<html>([\s\S]*?)<\/html>/i);
            if (match) {
                const iframe = document.createElement('iframe');
                iframe.style.width = '100%';
                iframe.style.height = '100%';
                iframe.style.border = 'none';
                // Security Fix: Sandbox the iframe to isolate preview DOM from Acode host origin & localStorage
                iframe.setAttribute('sandbox', 'allow-scripts allow-modals');
                iframe.srcdoc = match[1];
                body.innerHTML = '';
                body.appendChild(iframe);
            } else {
                body.innerText = 'No <html>...</html> block found in current document to render.';
            }
        }
    }

    previewHtml() {
        this.showPanelOutput('', 'success', 0);
        this.switchTab('html');
    }

    closePanel() {
        const panel = document.getElementById('block-console-panel');
        if (panel) panel.style.display = 'none';
    }

    async destroy() {
        editorManager.off('switch-file', this._onFileUpdate);
        editorManager.off('rename-file', this._onFileUpdate);
        if (editorManager.editor) editorManager.editor.off('change', this._onEditorChange);
        
        try {
            editorManager.editor.commands.removeCommand('Run Block Engine Code');
            editorManager.editor.commands.removeCommand('Format Block Code');
        } catch (_) {}

        const style = document.getElementById('block-plugin-style');
        if (style) style.remove();
        const quickBar = document.getElementById('block-quick-bar');
        if (quickBar) quickBar.remove();
        this.closePanel();
        if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
        if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
    }
}

if (window.acode) {
    const acodePlugin = new BlockPlugin();
    acode.setPluginInit(pluginId, function(baseUrl, $page, options) {
        acodePlugin.baseUrl = baseUrl;
        acodePlugin.init($page);
    });
    
    acode.setPluginUnmount(pluginId, function() {
        acodePlugin.destroy();
    });
}
